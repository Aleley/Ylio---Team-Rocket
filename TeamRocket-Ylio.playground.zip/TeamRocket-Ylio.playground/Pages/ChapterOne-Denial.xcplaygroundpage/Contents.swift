import SwiftUI
import PlaygroundSupport
import Foundation

//chapterOne = "Denial"


struct FirstView: View {        //Creazione della prima view del playground
    var body: some View {       //Variabile da dichiarare in tutte le View perchè devi definire di cosa è fatta la View --> Altre View
        
        ZStack{        //Zstack serve a mettere in sovrapposizione più View
          

            Rectangle()     //Creo un rettangolo con le sue proprietà
                .fill(Color.white)
                .frame(width: 500, height: 500)
                .aspectRatio(contentMode: .fit)
              RoundedRectangle (cornerRadius: 20)
                .frame(width: 500, height: 100)
            HStack{
                VStack(alignment: .leading) {        //Vstack mette gli elementi in ordine verticale
                Button("Hi. Breathe, the worst is over, you don't have to worry anymore. I know it's going to be hard to accept, but everything you knew, everything you were used to doesn't matter anymore.")
                    {
                    PlaygroundPage.current.setLiveView(ContentView())       //Ti indirizza alla View ContentView
                    }.font(.subheadline)
                        .foregroundColor(.white)
            }
            }
            .frame(width: 500, height: 75)
                        .padding()
                        .foregroundColor(.primary)
                        .background(Color.primary
                                        .colorInvert()
                                        .opacity(0.30))
        }
        
    }
}



var i = 0
struct BaseView: View {     //BaseView è la schermata di default con 3 elementi, viene richiamata nelle altre View
    @State var opaylioOne: CGFloat = 1
    @State var opaylioTwo: CGFloat = 0
    
    var body: some View {
    
        Image(uiImage: #imageLiteral(resourceName: "ylio1.jpg"))
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 500)
            .opacity(opaylioOne)
            
        Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 500)
            .opacity(opaylioTwo)
        
        RoundedRectangle(cornerRadius: 20)
                   // .padding(.horizontal)
                    .frame(width: 500, height: 100)
                    .offset(x: 0 ,y: 185)
                    .opacity(0.50)
    }
}
struct ContentView: View{       //Main View con le scelte
   
    @State var opaylioOne: CGFloat = 1
    @State var opaylioTwo: CGFloat = 0
    var body: some View{
               
        ZStack {
            
                Image(uiImage: #imageLiteral(resourceName: "ylio1.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500)
                    .opacity(opaylioOne)
                Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500)
                    .opacity(opaylioTwo)
                RoundedRectangle(cornerRadius: 20)
                            .frame(width: 500, height: 100)
                            .offset(x: 0 ,y: 185)
                            .opacity(0.50)
            VStack {
                Button ("Who are you?"){
                    if i >= 5{
                        label :do{
                        PlaygroundPage.current.setLiveView(nextSce())
                        }
                    }
                    else   {
                        i = i+1
                             label :do {
                           PlaygroundPage.current.setLiveView(ansOne())
                       }
                    }
                }
                Button ("What is this place?"){
                    if i >= 5{
                        label :do{
                        PlaygroundPage.current.setLiveView(nextSce())
                        }
                    }
                    else {
                        i = i+1
                        label :do {
                            PlaygroundPage.current.setLiveView(ansTwo())}
                    }
                }
                Button ("What are you talking about? I don't believe you!"){
                    if i >= 5{
                            label :do{
                            PlaygroundPage.current.setLiveView(nextSce())
                        }
                    }
                    else {
                        i = i+1
                         label :do {
                             PlaygroundPage.current.setLiveView(ansThree())
                         }
                    }
                }
            }
            .foregroundColor(.white)
            .offset(x: 0 ,y: 185)
            .onTapGesture {
                let YlioAnimation = Animation.easeIn(duration: 5)
                    .repeatCount(2)
                withAnimation(YlioAnimation){
                    (opaylioOne) = 0
                   (opaylioTwo) = 1
                    
                }
            }
          
        }
    }
}

struct ansOne: View{
    @State var opaylioOne: CGFloat = 0
    @State var opaylioTwo: CGFloat = 1
    var body: some View{
        ZStack {
            
                Image(uiImage: #imageLiteral(resourceName: "ylio1.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500)
                    .opacity(opaylioOne)
                    
                Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500)
                    .opacity(opaylioTwo)
                
                RoundedRectangle(cornerRadius: 20)
                           // .padding(.horizontal)
                            .frame(width: 500, height: 100)
                            .offset(x: 0 ,y: 185)
                            .opacity(0.50)
            
            VStack{
                Text("I am Ylio, and I will accompany you through this journey of yours.")
                    .multilineTextAlignment(.leading)
                    .frame(width: 400)
                    .font(.body)
                
                Button ("Next"){
                    if i >= 5{
                        label :do{
                        PlaygroundPage.current.setLiveView(nextSce())
                        }
                    }
                    else {
                        i = i+1
                      
                        label : do{
                            PlaygroundPage.current.setLiveView(ContentView())
                        }
                    }
               //     PlaygroundPage.current.setLiveView(ContentView())
                }
                .onTapGesture {
                    let YlioAnimation = Animation.easeIn(duration: 5)
                        .repeatCount(2)
                    withAnimation(YlioAnimation){
                        (opaylioOne) = 1
                       (opaylioTwo) = 0
                    }
                }
            }.foregroundColor(.white)
            .offset(x: 0 ,y: 185)}
        }
}

struct ansTwo: View{
    @State var opaylioOne: CGFloat = 0
    @State var opaylioTwo: CGFloat = 1
    var body: some View{
        ZStack {
            
                Image(uiImage: #imageLiteral(resourceName: "ylio1.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500)
                    .opacity(opaylioOne)
                    
                Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500)
                    .opacity(opaylioTwo)
                
                RoundedRectangle(cornerRadius: 20)
                           // .padding(.horizontal)
                            .frame(width: 500, height: 100)
                            .offset(x: 0 ,y: 185)
                            .opacity(0.50)
         
            VStack{
                Text("This is the everything. This is the nothingness. This is the beginning.  This is the end. In other words, this is the afterlife. You are dead.")
                    .multilineTextAlignment(.leading)
                    .frame(width: 400)
                    .font(.body)
                Button ("Next"){
                    if i >= 5{
                        label :do{
                        PlaygroundPage.current.setLiveView(nextSce())
                        }
                    }
                    else {
                        i = i+1
                      
                        label : do{
                            PlaygroundPage.current.setLiveView(ContentView())
                        }
                    }
                  //  PlaygroundPage.current.setLiveView(ContentView())
                }
                .onTapGesture {
                    let YlioAnimation = Animation.easeIn(duration: 5)
                        .repeatCount(2)
                    withAnimation(YlioAnimation){
                        (opaylioOne) = 1
                       (opaylioTwo) = 0
                        
                    }
                }
            }.foregroundColor(.white)
                .offset(x: 0 ,y: 185)
        }
    }
}

struct ansThree: View{
    @State var opaylioOne: CGFloat = 0
    @State var opaylioTwo: CGFloat = 1
    var body: some View{
        
        
        ZStack {
            
                Image(uiImage: #imageLiteral(resourceName: "ylio1.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500)
                    .opacity(opaylioOne)
                    
                Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500)
                    .opacity(opaylioTwo)
                
                RoundedRectangle(cornerRadius: 20)
                           // .padding(.horizontal)
                            .frame(width: 500, height: 100)
                            .offset(x: 0 ,y: 185)
                            .opacity(0.50)
       
            VStack{
                Text("It's okay not to believe me, it's part of the journey, \n but in time you will come to reconciliation. \nEveryone gets to reconciliation.")
                    .multilineTextAlignment(.leading)
                    .frame(width: 400)
                    .font(.body)
                Button ("Next") {
                    if i >= 5{
                        label :do{
                        PlaygroundPage.current.setLiveView(nextSce())
                        }
                    }
                    else {
                        i = i+1
                      
                        label : do{
                            PlaygroundPage.current.setLiveView(ContentView())
                        }
                    }
                //    PlaygroundPage.current.setLiveView(ContentView())
                }
                .onTapGesture {
                    let YlioAnimation = Animation.easeIn(duration: 5)
                        .repeatCount(2)
                    withAnimation(YlioAnimation){
                        (opaylioOne) = 1
                       (opaylioTwo) = 0
                        
                    }
                }
            }.foregroundColor(.white)
                .offset(x: 0 ,y: 185)
        }
    }
}
        
struct nextSce: View{
    var body: some View{
       
        ZStack{
        BaseView()
        Text ("Next chapter").foregroundColor(Color.white)
                .multilineTextAlignment(.leading)
                .frame(width: 400)
                .offset(x: 0 ,y: 185)
                .font(.body)
        }
    }
}


//: [Next Page](@next)

PlaygroundPage.current.setLiveView(FirstView())

