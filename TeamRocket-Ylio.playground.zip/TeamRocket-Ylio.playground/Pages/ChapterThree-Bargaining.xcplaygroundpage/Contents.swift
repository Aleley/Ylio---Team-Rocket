//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport
import Foundation

//chapterThree = "Bargaining"
struct BaseView: View {     //BaseView è la schermata di default con 3 elementi, viene richiamata nelle altre View
    var body: some View {
        
        Image(uiImage: #imageLiteral(resourceName: "ylio1.jpg"))
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 500)
           
        RoundedRectangle(cornerRadius: 20)
                   // .padding(.horizontal)
                    .frame(width: 500, height: 200)
                    .offset(x: 0 ,y: 185)
                    .opacity(0.50)
    }
}
struct ContentView: View{
    var body: some View {
        ZStack{
        BaseView()
            VStack{
            
Button ("No, that can't be right, there must be something I can do to avoid this."){
    label :do {
        PlaygroundPage.current.setLiveView(ChoiceOne())
            }
    
}.multilineTextAlignment(.leading)
                 .frame(width: 500, height: 60)
                 .lineLimit(8)
  
                
Button ("This is a sadistic game, let's stop it. Tell me what I have to do to end this."){
    label :do {
        PlaygroundPage.current.setLiveView(ChoiceTwo())
    }
  
    
}  .multilineTextAlignment(.leading)
                 .frame(width: 500, height: 60)
                 .lineLimit(8)
        
}.foregroundColor(.white)

            .offset(x: 0 ,y: 175)
}
    }
}

struct ChoiceOne: View{
    var body: some View{
        ZStack{
            Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 500)
                
            
            RoundedRectangle(cornerRadius: 20)
                       // .padding(.horizontal)
                        .frame(width: 500, height: 200)
                        .offset(x: 0 ,y: 185)
                        .opacity(0.50)
            VStack{
                
        Text("You can't avoid the inevitable. Nothing you have done in life can help you here: your experiences, your knowledge, are zeroed out here. You are a consciousness blocked by a shell, but here I will help you abandon it and spend eternity free.")
                    .multilineTextAlignment(.leading)
                    .frame(width: 400)
        Button (">"){
            label: do{
                PlaygroundPage.current.setLiveView(NextChap())
            }
        } .multilineTextAlignment(.leading)
                    .frame(width: 400)
                
    }.foregroundColor(.white)
            .offset(x: 0 ,y: 175)
        }
    }
}
struct ChoiceTwo: View{
    var body: some View{
        ZStack{
            Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 500)
                
            
            RoundedRectangle(cornerRadius: 20)
                       // .padding(.horizontal)
                        .frame(width: 500, height: 200)
                        .offset(x: 0 ,y: 185)
                        .opacity(0.50)
            VStack{
        
        Text ("This is not a game, there are no rules to follow, no rules to bend, no rules to break; there is only me here, what I say is law, there is no other way.")
                    .multilineTextAlignment(.leading)
                                       .frame(width: 400)
        Button (">"){
        label: do{
            PlaygroundPage.current.setLiveView(NextChap())
        }
        }
    }.foregroundColor(.white)
            .offset(x: 0 ,y: 175)
}
    }
}
struct NextChap: View{
    var body: some View{
        ZStack{
        BaseView()
            VStack{
        Text ("Next Chapter")
    }.foregroundColor(.white)
            .offset(x: 0 ,y: 175)
}
    }
}
PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
