//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport
import Foundation
import AVFoundation
//chapterFive = "Acceptance"
struct BaseView: View {     //BaseView è la schermata di default con 3 elementi, viene richiamata nelle altre View
    var body: some View {
        
        Image(uiImage: #imageLiteral(resourceName: "ylio4.png"))
            .frame(width: 510, height: 900)

        RoundedRectangle(cornerRadius: 20)
                   // .padding(.horizontal)
                    .frame(width: 500, height: 100)
                    .offset(x: 0 ,y: 185)
                    .opacity(0.50)
    }
}

struct Death: View{
    var body: some View{
        Image(uiImage: #imageLiteral(resourceName: "dead.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500 , height: 800 , alignment: .top
            )
                    

    }
}

struct ContentView: View{
    let alignments: [TextAlignment] = [.leading, .center]
       @State private var alignment = TextAlignment.leading

    var body: some View {
        ZStack{
        BaseView()
            VStack{
        
   
        Button ("step forward"){
               label :do {
                   PlaygroundPage.current.setLiveView(End())
            }
}
      
            }.foregroundColor(.white)
            .offset(x: 0 ,y: 175)
}
    }
}
struct End: View{
    let alignments: [TextAlignment] = [.leading, .center]
       @State private var alignment = TextAlignment.leading

    var body: some View{
        
        ZStack{
        BaseView()
            VStack{
               
        Text ("You've taken your final step. You've made it. Nothing can hurt you now. Nothing can destroy you anymore. You are dead.")
                    .foregroundColor(.white)
                    .lineLimit(4)
                        .multilineTextAlignment(alignment)
                        .frame(width: 480, height: 50)
                        .offset(x: 0 ,y: 175)
        Button ("End"){
        label: do{
            
            PlaygroundPage.current.setLiveView(over())
        }
        
        }.foregroundColor(.white)
        .offset(x: 0 ,y: 175)
}
    }
}
}

struct over: View{
    var body: some View{
        ZStack(alignment: .bottom) {
             
                  Rectangle()
                      .fill(.white)
                      .frame(width: 500, height: 680)
                      .aspectRatio(contentMode: .fit)
                      .frame(width: 500)
                .offset(x: 0 ,y: 175)
                  RoundedRectangle(cornerRadius: 20)
                     // .padding(.horizontal)
                      .frame(width: 500, height: 100)
                  HStack {

                      VStack(alignment: .leading) {
                    
                          Button("Is this the end?") {
                              PlaygroundPage.current.setLiveView(SwiftUIAudioPlayerView())
                          }
                              .font(.subheadline)
                              
                      }

                  
                  .frame(width: 500, height: 75)
                  .padding()
                  .foregroundColor(.primary)
                  .background(Color.primary
                                  .colorInvert()
                                  .opacity(0.30))
              }
          }
    }
}
/*
struct scare: View{
    @State var AudioPlayer: AVAudioPlayer?

    var body: some View {
        ZStack{
            Image(uiImage: #imageLiteral(resourceName: "dead.jpg"))
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 500, height: 600, alignment: .top)
                        .clipped()
        onTapGesture {
            Bundle.main.url(forResource: "Jump", withExtension: "mp3")
            AudioPlayer?.prepareToPlay()
            AudioPlayer?.numberOfLoops = -1
            AudioPlayer?.play()
        }
        }
        }
    }
*/
struct SwiftUIAudioPlayerView: View {
    
  
    /// the audio player that will play your audio file. Can't be a local variable.
    /// Must be a @State property because we need to modify it later
    @State var audioPlayer: AVAudioPlayer?

    var body: some View {
        ZStack{
            VStack{
        Button(action: {
           
            self.playAudio() /// play audio when tapped
        }) {
            Death()
            /// what the button looks like
        }.onAppear(perform: self.playAudio)
            } .offset(x: 0 ,y: 175)
        }
    }
    func playAudio() { /// function to play audio

        /// the URL of the audio file.
        /// forResource = name of the file.
        /// withExtension = extension, usually "mp3"
        if let audioURL = Bundle.main.url(forResource: "Jump", withExtension: "mp3") {
            do {
                try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
                self.audioPlayer?.numberOfLoops = 0 /// Number of times to loop the audio
                self.audioPlayer?.play() /// start playing

            } catch {
                print("Couldn't play audio. Error: (error)")
            }

        } else {
            print("No audio file found")
        }
    }
}
let swiftuiAudioPlayerView = SwiftUIAudioPlayerView()

PlaygroundPage.current.setLiveView(ContentView())


