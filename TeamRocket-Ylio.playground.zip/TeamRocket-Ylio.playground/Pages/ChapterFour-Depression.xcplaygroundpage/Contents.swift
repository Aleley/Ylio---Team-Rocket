//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport
import Foundation

//chapterFour = "Depression"
struct BaseView: View {
    
    //BaseView è la schermata di default con 3 elementi, viene richiamata nelle altre View
    var body: some View {
        
       
        Image(uiImage: #imageLiteral(resourceName: "ylio1.jpg"))
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 500)
            
        
        RoundedRectangle(cornerRadius: 20)
                   // .padding(.horizontal)
                    .frame(width: 500, height: 200)
                    .offset(x: 0 ,y: 185)
                    .opacity(0.50)
    }
}

struct ContentView: View{
    let alignments: [TextAlignment] = [.leading]
       @State private var alignment = TextAlignment.leading
    var body: some View {
        ZStack{
            BaseView()
            VStack{
    
                Button ("*you bend over and start shaking*  \n NO, IT'S NOT TRUE. I DON'T ACCEPT IT, NO! \n *fingers through your hair, you keep shaking.*"){
               label :do {
                   PlaygroundPage.current.setLiveView(ChoiceOne())
            }
                }.multilineTextAlignment(.leading)
               
                .frame(width: 550, height: 65)
                .lineLimit(8)
                
     
                
Button ("*you throw yourself on your knees* \n I beg you, HELP ME! \n *start sobbing*"){
    label :do {
        PlaygroundPage.current.setLiveView(ChoiceTwo())
    }
}
.multilineTextAlignment(.leading)

.frame(width: 450, height: 80)
                    .lineLimit(8)
}
            .foregroundColor(.white)
            .offset(x: 0 ,y: 165)
}
    }
}
struct ChoiceOne: View{
    var body: some View{
        ZStack{
            Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 500)
                
            
            RoundedRectangle(cornerRadius: 20)
                       // .padding(.horizontal)
                        .frame(width: 500, height: 200)
                        .offset(x: 0 ,y: 185)
                        .opacity(0.50)
            VStack{
        
        Text("You have no choice now. Eternity won't take no for an answer. Give me your hand.")
                    .multilineTextAlignment(.leading)
                                .frame(width: 450, height: 45)
                                .lineLimit(4)
        Button (">"){
        label: do{
            PlaygroundPage.current.setLiveView(NextChap())
        }
        }.multilineTextAlignment(.leading)
                    .frame(width: 550, height: 45)
                    .lineLimit(4)
                
    }
            .foregroundColor(.white)
            .multilineTextAlignment(.leading)
            .offset(x: 0 ,y: 175)
}
    }
}
struct ChoiceTwo: View{
    var body: some View{
        ZStack{
            Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 500)
                
            
            RoundedRectangle(cornerRadius: 20)
                       // .padding(.horizontal)
                        .frame(width: 500, height: 200)
                        .offset(x: 0 ,y: 185)
                        .opacity(0.50)
            VStack{
        
        Text("That's what I'm here for. Give me your hand.")
                    .multilineTextAlignment(.leading)
                                .frame(width: 450, height: 45)
                                .lineLimit(4)
        Button (">"){
        label: do{
            PlaygroundPage.current.setLiveView(NextChap())
        }
        }.multilineTextAlignment(.leading)
                    .frame(width: 550, height: 45)
                    .lineLimit(4)
                
    }
            .foregroundColor(.white)
            .multilineTextAlignment(.leading)
            .offset(x: 0 ,y: 175)
}
    }
}
struct NextChap: View{
    var body: some View{
        ZStack{
            Image(uiImage: #imageLiteral(resourceName: "ylio3.jpg"))
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 400, height: 600)
            RoundedRectangle(cornerRadius: 20)
                       // .padding(.horizontal)
                        .frame(width: 150, height: 100)
                        .offset(x: 0 ,y: 170)
                        .opacity(0.50)
            VStack{
        
        Text ("Next Chapter")
    }
            .foregroundColor(.white)
            .multilineTextAlignment(.leading)
            .offset(x: 0 ,y: 175)
}
    }
}
PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
