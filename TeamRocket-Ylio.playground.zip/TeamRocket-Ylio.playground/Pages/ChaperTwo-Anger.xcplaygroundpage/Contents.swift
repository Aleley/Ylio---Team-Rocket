//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport
import Foundation

var hit = Bool()
var i = 0
var ii = 0
//chapterTwo = "Anger"
struct BaseView: View {
    @State var opaylioOne: CGFloat = 1
    @State var opaylioTwo: CGFloat = 0
    //BaseView è la schermata di default con 3 elementi, viene richiamata nelle altre View
    var body: some View {
        
        Image(uiImage: #imageLiteral(resourceName: "ylio1.jpg"))
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 500)
        /*Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 500)*/
        
        RoundedRectangle(cornerRadius: 20)
                   // .padding(.horizontal)
                    .frame(width: 500, height: 100)
                    .offset(x: 0 ,y: 185)
                    .opacity(0.50)
      
    }
}


struct ContentView: View{
    @State var opaylioOne: CGFloat = 1
    @State var opaylioTwo: CGFloat = 0
    var body: some View {
        ZStack{
            Image(uiImage: #imageLiteral(resourceName: "ylio1.jpg"))
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 500)
                .opacity(opaylioOne)
            Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 500)
                .opacity(opaylioTwo)
            
            RoundedRectangle(cornerRadius: 20)
                       // .padding(.horizontal)
                        .frame(width: 500, height: 100)
                        .offset(x: 0 ,y: 185)
                        .opacity(0.50)
          
            VStack{
   
        Button ("Shut up! *give Ylio a punch*"){
               label :do {
                   PlaygroundPage.current.setLiveView(Punch())
            }
}
      
}.foregroundColor(.white)
            .offset(x: 0 ,y: 175)
}
}
}
struct Punch: View{
    var body: some View {
        ZStack{
            Image(uiImage: #imageLiteral(resourceName: "yliopunch.jpg"))
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 500)
                
          
            
            
            RoundedRectangle(cornerRadius: 20)
                       // .padding(.horizontal)
                        .frame(width: 500, height: 100)
                        .offset(x: 0 ,y: 185)
                        .opacity(0.50)
          
            VStack{
      
        Button (">"){
            PlaygroundPage.current.setLiveView(Punchagain())
        }
    }.foregroundColor(.white)
            .offset(x: 0 ,y: 175)
}
}
}
struct Punchagain: View{
   
    var body: some View{
        ZStack{
            
                Image(uiImage: #imageLiteral(resourceName: "ylio5.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500)
                RoundedRectangle(cornerRadius: 20)
                           // .padding(.horizontal)
                            .frame(width: 500, height: 100)
                            .offset(x: 0 ,y: 185)
                            .opacity(0.50)
            VStack{
                Text ("<It's okay, it's normal to feel this way. Go ahead if you want, let it all out. Get out all the residual impurity left in your spirit.>")
                            .multilineTextAlignment(.leading)
                                                .frame(width: 400)
                                              
        Button ("I said shut up! *punch*"){
            label :do {
                PlaygroundPage.current.setLiveView(Choice())
            }
                            }
    }.foregroundColor(.white)
            .offset(x: 0 ,y: 175)
}
}
}
struct Choice: View{
    @State var opaylioOne: CGFloat = 0
    @State var opaylioTwo: CGFloat = 0
    @State var opaylioThree: CGFloat = 1
    
    var body: some View{
        ZStack{
            
                Image(uiImage: #imageLiteral(resourceName: "ylio5.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500)
                     .opacity(opaylioOne)
              
                Image(uiImage: #imageLiteral(resourceName: "ylio6.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500)
                    .opacity(opaylioTwo)
            Image(uiImage: #imageLiteral(resourceName: "yliopunch.jpg"))
                .frame(width: 500, height: 900)
                .opacity(opaylioThree)
          
                
                RoundedRectangle(cornerRadius: 20)
                           // .padding(.horizontal)
                            .frame(width: 500, height: 100)
                            .offset(x: 0 ,y: 185)
                            .opacity(0.50)
              
          
            VStack{
        Text ("<Continue, I'll wait for you to finish>")
                    .multilineTextAlignment(.leading)
                                        .frame(width: 400)
        Button ("Keep punch him"){
                    i = i+1
            if ii <= 0
                {
                    (opaylioOne) = 0
                   (opaylioTwo) = 0
                    (opaylioThree) = 1
                    ii = ii + 1
            }
                else{
                    (opaylioOne) = 1
                   (opaylioTwo) = 0
                    (opaylioThree) = 0
                    ii = ii - 1
                }
                   
              if i > 8{
                   
                            (opaylioOne) = 0
                           (opaylioTwo) = 1
                            (opaylioThree) = 0
                    }
                }   .foregroundColor(.white)
                    
                
            
        
Button ("Put your hands down in surrender "){
 label :do {
     PlaygroundPage.current.setLiveView(Forward())
}
        }
    }
            .foregroundColor(.white)
            .offset(x: 0 ,y: 175)
}
}
}
struct Forward: View{
    var body: some View{
        ZStack{
            Image(uiImage: #imageLiteral(resourceName: "ylio2.jpg"))
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 500)
            RoundedRectangle(cornerRadius: 20)
                       // .padding(.horizontal)
                        .frame(width: 500, height: 100)
                        .offset(x: 0 ,y: 185)
                        .opacity(0.50)
            VStack{
        Text ("Good, we can continue now.")
                    .multilineTextAlignment(.leading)
                                        .frame(width: 400)
        Button (">"){
        label: do{
            PlaygroundPage.current.setLiveView(NextChapter())
        }
        }
        
    }.foregroundColor(.white)
            .offset(x: 0 ,y: 175)
}
}
}
struct NextChapter: View{
    var body: some View{
        ZStack{
        BaseView()
            VStack{
        Text ("next chapter")
                    .multilineTextAlignment(.leading)
                                        .frame(width: 400)
                                     
    }.foregroundColor(.white)
            .offset(x: 0 ,y: 175)
}
}
}
PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
